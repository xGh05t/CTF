def encrypt(cleartext):
    encrypted_list=list(zip(cleartext, list(reversed(cleartext)))) # [(x,y), (x,y), . . .]
    encrypted_str=""
    for x, y in encrypted_list:
        encrypted_str+=x+y
    return encrypted_str
    
def decrypt(ciphertext):
    decrypted_str=""
    
    for i in range(0, len(ciphertext), 2):
        decrypted_str += ciphertext[i]
    return decrypted_str

print(decrypt('f}ltangi{rppr{ignatl}f')) # Print the flag
