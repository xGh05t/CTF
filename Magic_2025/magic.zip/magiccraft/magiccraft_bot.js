const mineflayer = require('mineflayer');
const { mineflayer: viewer } = require('prismarine-viewer');
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
const fs = require('fs');
const path = require('path');

const bot = mineflayer.createBot({
  host: 'web.ctfmagic.org',
  port: 25565,
  username: 'magicFlagFinder',
  auth: 'offline'
});

bot.loadPlugin(pathfinder);

bot.once('spawn', () => {
  console.log("Bot connected and spawned.");

  // Start 3D viewer
  viewer(bot, { port: 3007, firstPerson: true });

  // Set movement
  const mcData = require('minecraft-data')(bot.version);
  const defaultMove = new Movements(bot, mcData);
  bot.pathfinder.setMovements(defaultMove);

  // Begin exploring and searching
  exploreAndSearch();
});

function exploreAndSearch() {
  setInterval(() => {
    // Pick a random nearby block to walk to
    const x = bot.entity.position.x + Math.floor(Math.random() * 40 - 20);
    const z = bot.entity.position.z + Math.floor(Math.random() * 40 - 20);
    const y = bot.entity.position.y;

    bot.pathfinder.setGoal(new goals.GoalBlock(x, y, z));

    // While walking, scan nearby structures
    scanForClues();
  }, 10 * 1000); // every 10 seconds
}

function scanForClues() {
  const radius = 15;
  const targets = bot.findBlocks({
    matching: block => block.name.includes('sign') || block.name.includes('banner') || block.name.includes('chest'),
    maxDistance: radius,
    count: 20
  });

  for (const pos of targets) {
    const block = bot.blockAt(pos);

    // Sign text detection
    if (block.name.includes('sign')) {
      const sign = bot.getSignText ? bot.getSignText(block) : block.getSignText?.();

      if (sign && typeof sign === 'object' && Array.isArray(sign.text)) {
        const text = sign.text.join(' ');
        handleFlagDetection(text, block.position);
      } else if (sign?.text) {
        handleFlagDetection(sign.text, block.position);
      }
    }

    // Add additional checks for items/containers if needed
    // For now, we focus on signs
  }
}

function handleFlagDetection(text, pos) {
  if (text.includes('flag{')) {
    const message = `\ud83d\udea9 Flag found: ${text} at ${pos}`;
    console.log(message);

    // Save screenshot-style log
    const logPath = path.join(__dirname, 'flag_log.txt');
    const entry = `[${new Date().toISOString()}] ${message}\n`;
    fs.appendFileSync(logPath, entry);
  }
}

bot.on('kicked', console.log);
bot.on('error', console.log);

