flag = ""
alphabet = "amvtpisreychoqnkdzlfgjbuwx"
s = ""
for c in flag:
    h = ord(c) ^ 0x80
    h = h << 20
    s += str(h)
for char in s:
    print(alphabet[int(char)], end="")

